# Import necessary libraries
import os
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Define function to load .dat files
def load_dat_files():
    data_list = []
    for file in os.listdir('.'):
        if file.endswith('.dat'):
            data = pd.read_csv(file, delim_whitespace=True, header=None).values
            data_list.append(data)
    return data_list

# Load and concatenate data
def concatenate_data(data_list):
    concatenated_data = np.vstack(data_list)
    return concatenated_data

# Normalize RPM and Torque
def normalize_data(data, TorqueMax, RPM_Max):
    RPM = data[:, 0]
    Torque = data[:, 1]
    z = data[:, 2]
    
    # Normalizing RPM and Torque
    RPM_norm = (RPM - RPM.min()) * (RPM_Max / (RPM.max() - RPM.min()))
    Torque_norm = (Torque - Torque.min()) * (TorqueMax / (Torque.max() - Torque.min()))
    
    # Mirroring Torque about the middle of the Torque-axis
    Torque_mid = TorqueMax / 2  # Middle of Torque-axis
    Torque_mirrored = Torque_mid + (Torque_mid - Torque_norm)
    
    normalized_data = np.column_stack((RPM_norm, Torque_mirrored, z))
    return normalized_data

# Create custom polynomial features for IPM
def create_ipm_polynomial_features(X):
    RPM = X[:, 0]
    Torque = X[:, 1]
    
    features = np.column_stack([
        Torque,          # a*Torque
        Torque**2,       # b*Torque^2
        RPM,             # c*RPM
        RPM * Torque**2, # d*RPM*Torque^2
        RPM**2,          # e*RPM^2
        RPM**2 * Torque**2, # f*RPM^2*Torque^2
        RPM**3           # g*RPM^3
    ])
    
    return features

# Create custom polynomial features for SPM
def create_spm_polynomial_features(X):
    RPM = X[:, 0]
    Torque = X[:, 1]
    
    features = np.column_stack([
        Torque**2,       # a*Torque^2
        RPM,             # b*RPM
        RPM**2,          # c*RPM^2
        RPM**2 * Torque**2, # d*RPM^2*Torque^2
        RPM**3           # e*RPM^3
    ])
    
    return features

# Create custom polynomial features for IM
def create_im_polynomial_features(X):
    RPM = X[:, 0]
    Torque = X[:, 1]
    
    features = np.column_stack([
        np.ones(len(RPM)), # a
        Torque,            # b*Torque
        Torque**2,         # c*Torque^2
        RPM * Torque**2,   # d*RPM*Torque^2
        RPM**2,            # e*RPM^2
        RPM**2 * Torque,   # f*RPM^2*Torque
        RPM**2 * Torque**2, # g*RPM^2*Torque^2
        RPM**3             # h*RPM^3
    ])
    
    return features

# Perform polynomial regression
def perform_polynomial_regression(data, motor_type):
    X = data[:, :2]  # Using normalized RPM and Torque as predictors
    y = data[:, 2]   # z as the target

    # Create custom polynomial features based on motor type
    if motor_type == 'IPM':
        X_poly = create_ipm_polynomial_features(X)
    elif motor_type == 'SPM':
        X_poly = create_spm_polynomial_features(X)
    elif motor_type == 'IM':
        X_poly = create_im_polynomial_features(X)
    
    # Create the regression model
    linear_regression = LinearRegression()
    model = linear_regression.fit(X_poly, y)

    return model

# Save polynomial regression equation to file
def save_polynomial_regression_equation(model, motor_type, TorqueMax, RPM_Max):
    coeffs = model.coef_
    intercept = model.intercept_

    terms = []
    if motor_type == 'IPM':
        terms = [
            ("Torque", coeffs[0]),
            ("Torque^2", coeffs[1]),
            ("RPM", coeffs[2]),
            ("RPM*Torque^2", coeffs[3]),
            ("RPM^2", coeffs[4]),
            ("RPM^2*Torque^2", coeffs[5]),
            ("RPM^3", coeffs[6])
        ]
    elif motor_type == 'SPM':
        terms = [
            ("Torque^2", coeffs[0]),
            ("RPM", coeffs[1]),
            ("RPM^2", coeffs[2]),
            ("RPM^2*Torque^2", coeffs[3]),
            ("RPM^3", coeffs[4])
        ]
    elif motor_type == 'IM':
        terms = [
            ("1", coeffs[0]),
            ("Torque", coeffs[1]),
            ("Torque^2", coeffs[2]),
            ("RPM*Torque^2", coeffs[3]),
            ("RPM^2", coeffs[4]),
            ("RPM^2*Torque", coeffs[5]),
            ("RPM^2*Torque^2", coeffs[6]),
            ("RPM^3", coeffs[7])
        ]
    
    filename = f"{motor_type}_Torque{TorqueMax}_RPM{RPM_Max}.txt"
    with open(filename, 'w') as f:
        for term, coeff in terms:
            f.write(f"{term}:\t{coeff:.16f}\n")
        f.write(f"Intercept:\t{intercept:.16f}\n")
    print(f"Polynomial regression equation saved to {filename}")

# Plot 3D data and regression plane
def plot_3d_data_and_regression(data, model, motor_type):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # Scatter plot of the data points
    ax.scatter(data[:, 0], data[:, 1], data[:, 2], c='r', marker='o')

    # Create a meshgrid for plotting the regression surface
    RPM = np.linspace(0, 5500, 100)
    Torque = np.linspace(0, 250, 100)
    RPM, Torque = np.meshgrid(RPM, Torque)
    
    # Flatten the meshgrid and predict z values
    RPM_Torque = np.column_stack([RPM.ravel(), Torque.ravel()])
    if motor_type == 'IPM':
        RPM_Torque_poly = create_ipm_polynomial_features(RPM_Torque)
    elif motor_type == 'SPM':
        RPM_Torque_poly = create_spm_polynomial_features(RPM_Torque)
    elif motor_type == 'IM':
        RPM_Torque_poly = create_im_polynomial_features(RPM_Torque)
    
    efficiency = model.predict(RPM_Torque_poly).reshape(RPM.shape)

    # Plot the regression surface
    ax.plot_surface(RPM, Torque, efficiency, alpha=0.5)

    ax.set_xlabel('RPM')
    ax.set_ylabel('Torque')
    ax.set_zlabel('Efficiency')

    plt.show()

# Main script
if __name__ == "__main__":
    # Prompt the user for the type of motor
    motor_type = input("Enter the type of motor (IPM, IM, SPM): ").strip().upper()

    if motor_type not in ['IPM', 'IM', 'SPM']:
        print("Invalid motor type. Please enter IPM, IM, or SPM.")
    else:
        max_torque = float(input("Enter the maximum value of Torque in N-m: ").strip())
        max_rpm = float(input("Enter the maximum value of RPM: ").strip())

        # Step 1: Load .dat files
        data_list = load_dat_files()

        # Step 2: Concatenate data
        concatenated_data = concatenate_data(data_list)

        # Step 3: Normalize data
        normalized_data = normalize_data(concatenated_data, max_torque, max_rpm)

        # Step 4: Perform polynomial regression
        model = perform_polynomial_regression(normalized_data, motor_type)

        # Step 5: Save polynomial regression equation to file
        save_polynomial_regression_equation(model, motor_type, max_torque, max_rpm)

        # Step 6: Plot 3D data and regression surface
        plot_3d_data_and_regression(normalized_data, model, motor_type)
